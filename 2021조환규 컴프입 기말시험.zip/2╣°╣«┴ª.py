month_day = [31,28,31,30,31,30,31,31,30,31,30,31]
yoil = '목 금 토 일 월 화 수'.split()
all_date = 0
while True:
    M, D = map(int,input().split())
    if M < 0 :
        break

    if M == 0 or M > 12 or D < 1 or D > month_day[M-1] :
        print("적절한 월, 일을 입력해 주세요.")
    else :
        M -= 1
        for i in range(M) :
            all_date += month_day[i]
        all_date += D
        day_D7 = all_date%7
        print(yoil[day_D7])
