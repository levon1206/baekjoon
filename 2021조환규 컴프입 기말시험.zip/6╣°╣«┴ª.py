n = 0
def maxnum(L) :
    global n
    global max_number
    if n >= (len(L)) :
        L.remove(max_number)
        result.append(max_number)
        n = 0
        max_number = 0
        return
    else :
        if L[n] > max_number :
            max_number = L[n]
            n += 1
        else :
            n += 1
        return maxnum(L)

def Second_max( L ) :
    if len(L) <= 1 :
        print("Error"); return;

    if len(result) == 2 :
        return print(result[1])
    else :
        maxnum(L)

    Second_max(L)




max_number = 0
result = []
L=[ 4/34, 54/21, 65/55, 34/24, 76/45, 9/34, 34/22, 4/5, 5/6, 7/8, 9/5]
Second_max(L)