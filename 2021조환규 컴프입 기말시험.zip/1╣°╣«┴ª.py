import random
random.seed(20220620)
cnt = 0
for _ in range(50000) :
    x1 = random.random()
    y1 = random.random()
    x2 = 1 + random.random()
    y2 = 1 + random.random()
    if x1**2 + (2-y1)**2 <= 4 and (1-x1)**2 + y1**2 <= 1:
        cnt += 1
    if x2**2 + (2-y2)**2 <= 4 and (1-x2)**2 + y2**2 <= 1:
        cnt += 1

print(cnt/100000)
