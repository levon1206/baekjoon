def Deep_rotate(L) :
    for i in range(len(L)) :
        space = L[i][0]
        L[i].remove(space)
        if i == 0 :
            L[len(L)-1].append(space)
        else :
            L[i-1].append(space)
    return L

La=[ [3,4], [6], [11, 12, 13], [99 ], [55, 54, 53] ]
print(Deep_rotate(Deep_rotate(La)))