import pandas as pd

df = pd.read_excel('food.xlsx','price')
name_price_satisfy = {}
for i in df.index :
    name = df[df.columns[0]][i]
    price = int(df[df.columns[1]][i])
    satisfy = int(df[df.columns[2]][i])
    name_price_satisfy[name] = satisfy/price

price_satisfy = list(name_price_satisfy.values())
price_satisfy = list(set(price_satisfy))
price_satisfy.sort(reverse= True)

for n in price_satisfy :
    for w in name_price_satisfy :
        if name_price_satisfy[w] == n :
            print(f"{w} {name_price_satisfy[w]}")