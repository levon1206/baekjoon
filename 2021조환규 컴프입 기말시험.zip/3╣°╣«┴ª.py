remove_list = [",",".","!","?"]
word_list = {}
T = []

for _ in range(18) :
    text = input().lower().split()
    for w in text :
        if len(w) > 2 :
            for i in range(4) :
                while remove_list[i] in w :
                    print(w)
                    w = w[0:len(w)-1]

            if w not in word_list :
                word_list[w] = 1
            else :
                word_list[w] += 1

nums = word_list.values()
maxnum = max(nums)
for word in word_list :
    if word_list[word] == maxnum :
        print(word)