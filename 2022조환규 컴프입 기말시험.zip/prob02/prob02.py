# 기말고사 2번 문제

def show_time( T, K ) :
    print("Time Now", T )
    #--------------
    Out = (T[0],T[1],T[2]+K)
    while Out[2] >= 60 :
        Out = (Out[0],Out[1]+1,Out[2]-60)
    while Out[1] >= 60 :
        Out = (Out[0]+1,Out[1]-60,Out[2])

    # 이 부분을 채워서 완성하시오.
    #--------------
    return ( Out )


In = input("Type 현재 시간: h, m, s:" )
h,m,s= map(int, In.split() )
print( h,m,s )
T= (h,m,s)
K  = int(input("Type 추가시간  K: "))

result= show_time(T, K)
print( result )