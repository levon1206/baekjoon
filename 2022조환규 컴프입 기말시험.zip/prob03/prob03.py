# 문제 3번

# "45554136631411334"
def wash(L):
    if L[0] == L[1]:
        same = L[0]
        while same == L[1] :
            L.remove(L[1])
            L.remove(same)
        for i in range(L.index('/')) :
            L.append(L[0])
            L.remove(L[0])
    else :
        L.append(L[0])
        L.remove(L[0])

myline= input("Type L string: ") # 45554136631411334

mylist=list(myline)
while ' ' in mylist :
    mylist.remove(' ')
mylist.append('/')

while True :
    cnt = 0
    while True :
        if mylist[0] == mylist[1]:
            same = mylist[0]
            while same == mylist[1] :
                mylist.remove(mylist[1])
            mylist.remove(same)
        else :
            mylist.append(mylist[0])
            mylist.remove(mylist[0])
        if mylist[0] == '/' :
            break
        print(mylist)

    for i in range(len(mylist)-1) :
        if mylist[i] == mylist[i+1] :
            cnt += 1

    if cnt == 0 :
        break



mylist.remove('/')
if len(mylist) == 0 :
    print("mylist= ", "none" )
else :
    print("mylist= ", mylist )