remove_list = [",",".","!","?"]
word_list = {}
f = open("philo.txt", 'r',encoding='cp949')

# 가장 많이 나타난 길이 K이상인 단어를 모두 출력하는 함수
# 이 함수를 완성하시오.
def frequent( mywords, K) :
    for w in mywords :
        if len(w) >= K :
            for i in range(4) :
                while remove_list[i] in w :
                    w = w[0:len(w)-1]

            if w not in word_list :
                word_list[w] = 1
            else :
                word_list[w] += 1
    nums = word_list.values()
    if len(nums) == 0 :
        print("None")
    else :
        maxnum = max(nums)
        for word in word_list :
            if word_list[word] == maxnum :
                print(word)

    return
#

mydata = f.read( )
print("입력 문서의 길이 : ",  len(mydata))
print("입력 문서의 유형 : ",   type(mydata) )

mywords = mydata.split()
print("분리된 총 token의 수 : ", len(mywords))

K = int( input("제한 길이 K:"))

count=0
for w in mywords :
    if len(w) > K : count += 1

print(f"제한 길이 K 이상의 단어 수 = {count}")
f.close()

frequent(mywords, K)