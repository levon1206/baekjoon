# 기말고사 1번 문제
import random
random.seed(2022)

def hand():
    rps ="가위 바위 보".split()
    return random.choice( rps )

cnt = 0
space = []
for _ in range(100000) :
    while True :
        space = []
        for _ in range(5) :
            space.append(hand())
        space = set(space)
        cnt += 1
        if len(space) == 2 :
            break
print(cnt/100000)