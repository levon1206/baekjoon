
"""
문제 6번, Sympy를 이용한 적분과 방정식 해결
"""
import sympy as sym
from sympy.solvers.solveset import linsolve
import math

x, y, z, u, v  = sym.symbols('x, y, z, u, v')
fx = (x + sym.sin(x))/(1+ sym.cos(x))
print(sym.integrate(fx,(x,0, sym.pi / 2)))

Waht = sym.Matrix([
         [ 3,-6, 1, 5,-4, 2],
         [ 1, 4,-2, 1, 8, 1],
         [ 1, 2, 3, 4,-1, 11],
         [-1,-1, 5,-3, 1,-1],
         [ 2,-5,-1, 3,-3,-2]])


sol = linsolve(Waht,(x,y,z,u,v))
print(sol)